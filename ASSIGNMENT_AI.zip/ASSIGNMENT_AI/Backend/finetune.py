# finetune.py
import json
import random
import argparse
import torch
import numpy as np
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments, Trainer
from transformers import DataCollatorWithPadding

# Set seeds
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

def read_data(jsonl_file):
    data = []
    with open(jsonl_file, 'r') as f:
        for line in f:
            obj = json.loads(line)
            label = 1 if obj["label"].lower() == "positive" else 0
            data.append({"text": obj["text"], "label": label})
    return Dataset.from_list(data)

def tokenize(example, tokenizer):
    return tokenizer(example["text"], truncation=True)

def main(args):
    set_seed()

    # Load dataset
    dataset = read_data(args.data)
    tokenizer = AutoTokenizer.from_pretrained(args.model)

    dataset = dataset.map(lambda x: tokenize(x, tokenizer), batched=True)
    dataset = dataset.train_test_split(test_size=0.2)
    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

    # Load model
    model = AutoModelForSequenceClassification.from_pretrained(args.model, num_labels=2)

    # Training
    training_args = TrainingArguments(
        output_dir="/model",  
        evaluation_strategy="epoch",
        learning_rate=args.lr,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=16,
        num_train_epochs=args.epochs,
        weight_decay=0.01,
        save_strategy="epoch",
        logging_dir="./logs",
        seed=42
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset["train"],
        eval_dataset=dataset["test"],
        tokenizer=tokenizer,
        data_collator=data_collator
    )

    trainer.train()
    model.save_pretrained("/model")       
    tokenizer.save_pretrained("/model")    
    print("✅ Model fine-tuned and saved to /model")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="data.jsonl")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=3e-5)
    parser.add_argument("--model", type=str, default="distilbert-base-uncased")
    args = parser.parse_args()

    main(args)
