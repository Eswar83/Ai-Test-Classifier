from transformers import pipeline

# Load the fine-tuned model
classifier = pipeline("sentiment-analysis", model="./model", tokenizer="./model")

# Label map
label_map = {
    "LABEL_0": "negative",
    "LABEL_1": "positive"
}

# Test input
text = "I absolutely love this product!"
result = classifier(text)[0]

# Convert label
mapped_result = {
    "label": label_map.get(result["label"], "unknown"),
    "score": round(result["score"], 4)
}

print(mapped_result)
