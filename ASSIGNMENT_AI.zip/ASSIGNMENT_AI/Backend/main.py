from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import pipeline

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model from mounted /model path
classifier = pipeline("sentiment-analysis", model="/model", tokenizer="/model")

class InputText(BaseModel):
    text: str

@app.post("/predict")
def predict(data: InputText):
    print("Received text:", data.text)
    try:
        result = classifier(data.text)[0]
        print("Raw result:", result)

        label_map = {
            "LABEL_0": "negative",
            "LABEL_1": "positive",
            "positive": "positive",
            "negative": "negative"
        }

        return {
            "label": label_map.get(result["label"], "unknown"),
            "confidence": round(result["score"], 4)
        }
    except Exception as e:
        print("Error in prediction:", e)
        return {
            "label": "error",
            "confidence": 0
        }
