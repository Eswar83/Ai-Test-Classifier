from datasets import load_dataset
import json

# Load IMDb train set
dataset = load_dataset("imdb", split="train")

# Save small portion for fine-tuning
subset = dataset.shuffle(seed=42).select(range(1000))  # You can increase this

# Convert to JSONL format
with open("data.jsonl", "w") as f:
    for sample in subset:
        label = "positive" if sample["label"] == 1 else "negative"
        json.dump({"text": sample["text"], "label": label}, f)
        f.write("\n")
