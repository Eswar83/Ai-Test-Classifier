import React, { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handlePredict = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:8000/predict', { text }); 

      console.log("Backend response:", res.data);
      setResult(res.data);
    } catch (err) {
      console.error('Prediction error:', err);
      setResult({ label: 'error', confidence: 0 });
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-white to-indigo-200 p-6">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg p-8">
        <h1 className="text-3xl font-bold text-center mb-6 text-indigo-700">Sentiment Analyzer</h1>

        <textarea
          className="w-full border-2 border-indigo-300 p-4 rounded-lg text-lg focus:outline-none focus:ring focus:border-indigo-500"
          rows={5}
          placeholder="Enter your text here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        ></textarea>

        <div className="flex justify-center mt-4">
          <button
            onClick={handlePredict}
            disabled={loading}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg shadow hover:bg-indigo-700 transition duration-200"
          >
            {loading ? 'Analyzing...' : 'Predict'}
          </button>
        </div>

        {result && (
          <div className="mt-6 text-center">
            <p className="text-xl font-semibold text-gray-700">Result:</p>
            <p className={`mt-2 text-2xl font-bold ${
              result.label === 'positive' ? 'text-green-600' :
              result.label === 'negative' ? 'text-red-600' : 'text-gray-500'
            }`}>
              {result.label.toUpperCase()}
            </p>
            <p className="text-gray-500">
              Confidence: {(result.confidence * 100).toFixed(2)}%
            </p>
            <pre className="bg-gray-100 text-sm mt-4 p-2 rounded text-left">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
